console.log("yo!@");

angular
    .module('app', ['jsxGraph', 'ui.bootstrap']);